

<i class="fal fa-times" style="color: #ff2f8b;text-shadow: 0 0 5px #ff2f8b;font-weight: 700;"><span style="color:white; #ff2f8b;text-shadow: 0 0 5px white;"> Hatalı! </span> </i> <br><br> Başlık, yazar ve açıklama boş bırakılamaz.