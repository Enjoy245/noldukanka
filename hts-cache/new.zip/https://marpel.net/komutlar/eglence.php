
<!DOCTYPE html>
<html lang="en">
<head>


       <link rel="stylesheet" href="/css/style.css"/>
    <link rel="stylesheet" href="/css/komutlar.css"/>
  
	<link rel="shortcut icon" href="/resimler/marpel.png" type="image/x-icon" >

  		<link rel="shortcut icon" href="https://marpel.net/resimler/marpel.png" type="image/x-icon" >

		
      <meta charset="UTF-8">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.1.7/css/fork-awesome.min.css" integrity="sha256-gsmEoJAws/Kd3CjuOQzLie5Q3yshhvmo7YNtBG7aaEY=" crossorigin="anonymous">

	<link rel="shortcut icon" href="https://marpel.net/resimler/marpel.png" type="image/x-icon" >

		

     <title>Marpel Bot | Eğlence Komutları</title>
  </head>

<body>

    <img class="bg-image" src="https://marpel.net/marpel.png" aria-hidden="true" />


    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.1.7/css/fork-awesome.min.css" integrity="sha256-gsmEoJAws/Kd3CjuOQzLie5Q3yshhvmo7YNtBG7aaEY=" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css"/>
	

</head> 
<nav>
        <div class="nav-wrapper">
            <ul>
                <li><a href="/"><img src="https://marpel.net/marpel.png" alt="Marpel Logosu"></a></li>
            </ul>
            <div class="nav-items">
                <ul>
                    <li><a href="/" class="nav-item">Ana Sayfa</a></li>
                    <li><a href="/tanitimlar"
                         class="nav-item navv">Tanıtımlar</a></li>
                    <li><a href="/komutlar.php" class="nav-item navvv">Komutlar</a></li>
                  <li><a href="/embed"class="nav-item navvvv">Embed Oluşturucu</a></li>
                </ul>
            </div>
            <div class="nav-buttons">
              <ul>
                    <li><a href="https://discord.gg/t8dvKdr" target="_blank" 
                         class="btn white-hollow-btn">Destek Sunucusu</a></li>
                    <li><a href="https://discord.com/oauth2/authorize?client_id=490039330388180992&permissions=8&scope=bot" target="_blank" rel="noopener" class="btn primary-btn"><i class="fa fa-discord" aria-hidden="true"></i> Davet Et</a></li>
                                  <li><a href="https://discord.com/oauth2/authorize?client_id=490039330388180992&permissions=8&scope=bot" target="_blank" rel="noopener" class="nav-item"><i class="fal fa-sign-in fa-3x"></i></a></li>
                
              </ul>
            </div>
        </div>
    </nav>	

            <div class="section-wrapper">
        <center>
                <div class="overview-card">
                    <h1 class="brand">
                <a href="https://marpel.net/komutlar/moderasyon.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/moderasyon.png" title="Moderasyon komutlarını görmek için tıkla." width="32" height="32"></a>
            
            <a href="https://marpel.net/komutlar/extra.php"> <img class="ozellik_btn_i" src="https://marpel.net/resimler/extra.png" title="Extra komutlarını görmek için tıkla." width="32" height="32"></a>
            
            <a href="https://marpel.net/komutlar/rank.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/rank.png" title="Rank komutlarını görmek için tıkla." width="32" height="32"></a>
                              </h1>
                      </div>
        
		<script src="https://marpel.net/util/komutlar.js"></script>
      <script>
        function update() {
          myFunction();
          var rows = document.getElementById("myTable").rows;
          var count = -1;
          for (let i = 0;i<rows.length;i++) {
            if (rows[i].style[0]!="display") count++;
          }
          document.getElementById("cmdcount").innerHTML = `Komut [${count}]`;
        }  
      </script>
<center>
  <br />
			<input type="text" style="color:#fff" id="myInput" onkeyup="update()" placeholder="Komut Ara..." title="Aramak istediğiniz kelimeyi girin!">
			<br>
			<br>
      <div>
      <br>
			<table id="myTable">
				<tr class="header">
        
					<th style="width:auto%;" id="cmdcount"> <font color:"white">Komut  [30</font>]</th>
					<th style="width:auto%;">Açıklama</th>
        
       		<tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!dur</td><td>Çalan müziği durdurur.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!disconnect</td><td>Marpeli ses kanalından çıkarır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!trump <Metin></td><td>Trumpa fake tweet göndertir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!neçalıyor</td><td>Şu anda çalan müzik hakkında bilgi.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!konuştur <@Üye> <Metin></td><td>İstenen üyeye mesaj yazdırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!rastgele-üye</td><td>Rastgele bir üye hakkında bilgiler verir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!geç</td><td>Çalan müziği geçer.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!alıntıla <mesajid></td><td>İdsi girilen mesajı alıntılar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!rastgele-rol</td><td>Rastgele bir rol hakkında bilgiler verir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!tersçevir</td><td>Girilen yazıyı tersten yazar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!ye <@Üye></td><td>Deneyip öğrenebilirsiniz.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!rep <@Üye></td><td>Günde bir defa bir üyeye rep verebilirsiniz.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!tekraret</td><td>Çalan müziği tekrar sıraya ekler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!çal <müzik></td><td>Müzik çalar işte ne olsun.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!emoji-yazı <metin></td><td>Girilen yazıyı emojili şekilde yazar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!mc-başarı <yazı></td><td>Fotoğrafa yazı yazdırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!clyde <Metin></td><td>Clyde bota fake mesaj yazdırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!tkm <taş|kağıt|makas> <Sayı></td><td>Taş kağıt makas oyunu.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!kuyruk</td><td>Kuyruktaki müzikleri listeler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!kredi-gönder <Miktar> <@Üye></td><td>Kredi transferi</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!ses</td><td>Çalan müziğin sesini değiştirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!qr</td><td>İstediğiniz metni qr koduna dönüştürür.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!rastgele-emoji</td><td>Rastgele bir emoji hakkında bilgiler verir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!test</td><td>Mrtol'un özel komutu</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!sar <Süre></td><td>Çalan müziği ileri&geri sarar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!oy</td><td>Ödül kazanmak için oy verin.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!tweet <@üye> <metin></td><td>Fake tweet gönderttirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!pankart <Metin></td><td>Pankarta yazı yazdırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!kredi</td><td>Her gün 50 ile 350 arası kredi verir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/eglence.png"></a> m!hatırlatıcı <Süre></td><td>Belirlenen süre sonra mesaj atar</td>
			</table>

          </div>
      
		</center>
   
          </div>  
                      <center>
                
                    <h1 class="brand">
					
			<a href="https://marpel.net/komutlar/moderasyon.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/moderasyon.png" title="Moderasyon komutlarını görmek için tıkla." width="128" height="128"></a>

            <a href="https://marpel.net/komutlar/extra.php"> <img class="ozellik_btn_i" src="https://marpel.net/resimler/extra.png" title="Extra komutlarını görmek için tıkla." width="128" height="128"></a>
            
            <a href="https://marpel.net/komutlar/rank.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/rank.png" title="Rank komutlarını görmek için tıkla." width="128" height="128"></a>
            
                              </h1>
                     <br>
<style>

@media (max-width: 1170px) {
    .bg-image {
        width: 70vw;
    }

    .nav-items {
        display: none;
    }

    .nav-wrapper {
        grid-template-columns: 0.7fr 2.5fr;
    }

    .nav-buttons {
        display: grid;
        justify-content: right;
    }

    .nav-footer-holder {
        display: block;
        height: 60px;
        background: #222;
    }

    .nav-footer {
        display: block;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #222;

        box-shadow: 0 -1px 7px 1px black;

        animation: softpop 0.5s;

        z-index: 1000;
    }

    .nav-footer ul {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1fr;
        justify-content: center;
        
        list-style: none;

        text-align: center;
    }

    .nav-footer li {
        margin: 20px;
    }  
    .nav-footer i {
        display: block;
        font-size: 1.2rem;
    }

    .navf-item.active, .navf-item:hover, .navf-item:active {
        color: #ff2f8b;
        text-shadow: 0 0 10px #ff2f8b;
    }

/*
FOOTER START
*/
footer {
    background: #222;
    color: #ddd;
    padding: 15px 60px;
    top: auto;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    justify-content: center;
    align-items: center;
}

footer h3 {
    font-weight: 300;
}

footer img {
    width: 50px;
}

.footer-brand {
    display: grid;
    justify-content: left;
}
.footer-logo {
    display: grid;
    justify-content: center;
}
.footer-by {
    display: grid;
    justify-content: right;
}
.footer-by-col {
    display: grid;
    align-items: center;
    
    grid-template-columns: 1fr 1fr;
    column-gap: 20px;

    text-align: center;
}
/*
FOOTER END
*/

}

              
</style>
        <footer class="buFooter">
        <div class="footer-brand">
            <h3>Marpel <i class="fa fa-copyright glow-text" aria-hidden="true"></i> 2020</h3>
        </div>
        <div class="footer-logo">
            <img src="https://marpel.net/marpel.png" alt="Marpel Logosu">
        </div>
        <div class="footer-by">
            <div class="footer-by-col">
                <h3>Bot<br/><span class="glow-text">Mrtol</span></h3>
                <h3>Webmaster <br/><span class="glow-text">MegaCrafter</span></h3>
            </div>
        </div>
    </footer>

    <div class="nav-footer-holder"></div>
    <div class="nav-footer">
        <ul>
                    <li><a href="/" class="navf-item active">Ana Sayfa</a></li>
                    <li><a href="/tanitimlar"
                         class="navf-item">Tanıtımlar</a></li>
                    <li><a href="/komutlar.php" class="navf-item">Komutlar</a></li>
                <li><a href="/embed" class="navf-item">Embed Oluşturucu</a></li>
                </ul>
    </div>
    <script>function jqueryLoaded(){$(".nav>li").click(function(){$(".active").toggleClass("active"),$(this).toggleClass("active")});}</script>
	<script defer async src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" onload="jqueryLoaded"></script> 
  </body>
</html>
