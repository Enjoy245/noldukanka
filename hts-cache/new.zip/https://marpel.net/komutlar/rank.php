
<!DOCTYPE html>
<html lang="en">
<head>


       <link rel="stylesheet" href="/css/style.css"/>
    <link rel="stylesheet" href="/css/komutlar.css"/>
  
	<link rel="shortcut icon" href="/resimler/marpel.png" type="image/x-icon" >

  		<link rel="shortcut icon" href="https://marpel.net/resimler/marpel.png" type="image/x-icon" >

		
      <meta charset="UTF-8">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.1.7/css/fork-awesome.min.css" integrity="sha256-gsmEoJAws/Kd3CjuOQzLie5Q3yshhvmo7YNtBG7aaEY=" crossorigin="anonymous">

	<link rel="shortcut icon" href="https://marpel.net/resimler/marpel.png" type="image/x-icon" >

		

     <title>Marpel Bot | Rank Komutları</title>
  </head>

<body>

    <img class="bg-image" src="https://marpel.net/marpel.png" aria-hidden="true" />


    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.1.7/css/fork-awesome.min.css" integrity="sha256-gsmEoJAws/Kd3CjuOQzLie5Q3yshhvmo7YNtBG7aaEY=" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css"/>
	

</head> 
<nav>
        <div class="nav-wrapper">
            <ul>
                <li><a href="/"><img src="https://marpel.net/marpel.png" alt="Marpel Logosu"></a></li>
            </ul>
            <div class="nav-items">
                <ul>
                    <li><a href="/" class="nav-item">Ana Sayfa</a></li>
                    <li><a href="/tanitimlar"
                         class="nav-item navv">Tanıtımlar</a></li>
                    <li><a href="/komutlar.php" class="nav-item navvv">Komutlar</a></li>
                  <li><a href="/embed"class="nav-item navvvv">Embed Oluşturucu</a></li>
                </ul>
            </div>
            <div class="nav-buttons">
              <ul>
                    <li><a href="https://discord.gg/t8dvKdr" target="_blank" 
                         class="btn white-hollow-btn">Destek Sunucusu</a></li>
                    <li><a href="https://discord.com/oauth2/authorize?client_id=490039330388180992&permissions=8&scope=bot" target="_blank" rel="noopener" class="btn primary-btn"><i class="fa fa-discord" aria-hidden="true"></i> Davet Et</a></li>
                                  <li><a href="https://discord.com/oauth2/authorize?client_id=490039330388180992&permissions=8&scope=bot" target="_blank" rel="noopener" class="nav-item"><i class="fal fa-sign-in fa-3x"></i></a></li>
                
              </ul>
            </div>
        </div>
    </nav>	

            <div class="section-wrapper">
        <center>
                <div class="overview-card">
                    <h1 class="brand">
                <a href="https://marpel.net/komutlar/moderasyon.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/moderasyon.png" title="Moderasyon komutlarını görmek için tıkla." width="128" height="128"></a>
                        
            <a href="https://marpel.net/komutlar/extra.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/extra.png" title="Extra komutlarını görmek için tıkla." width="128" height="128"></a>
            
            <a href="https://marpel.net/komutlar/eglence.php"><img class="ozellik_btn_i"src="https://marpel.net/resimler/eglence.png" title="Eğlence komutlarını görmek için tıkla." width="128" height="128"></a>
                              </h1>
                      </div>
        
		<script src="https://marpel.net/util/komutlar.js"></script>
		<script src="https://marpel.net/util/komutlar.js"></script>
      <script>
        function update() {
          myFunction();
          var rows = document.getElementById("myTable").rows;
          var count = -1;
          for (let i = 0;i<rows.length;i++) {
            if (rows[i].style[0]!="display") count++;
          }
          document.getElementById("cmdcount").innerHTML = `Komut [${count}]`;
        }  
      </script>
<center>
  <br />
			<input type="text" style="color:#fff" id="myInput" onkeyup="update()" placeholder="Komut Ara..." title="Aramak istediğiniz kelimeyi girin!">
			<br>
			<br>
      <div>
      <br>
			<table id="myTable">
				<tr class="header">
        
					<th style="width:auto%;" id="cmdcount"> <font color:"white">Komut  [19</font>]</th>
					<th style="width:auto%;">Açıklama</th>
        
       		<tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!profilayar</td><td>Profil arka planı değiştirme.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!rankmuaf-çıkar <#Kanal></td><td>Tecrübe vermeyecek kanal çıkar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!tecrübe-al <Miktar> <@Üye></td><td>Üyeden tecrübe alma.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!profil</td><td>Profil kartınızı gönderir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviyerol-ekle <Seviye> <@Rol></td><td><a href=https://marpel.net/tanitim/rank target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!tecrübe-ayarla <Miktar> <@Üye></td><td>Üyenin tecrübesini ayarlama.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviyerol-çıkar <Seviye> <@Rol></td><td><a href=https://marpel.net/tanitim/rank target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!tecrübe-ver <Miktar> <@Üye></td><td>Tecrübe verme komutu.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!tecrübemiktar <sayı></td><td>Mesajların vereceği tecrübe miktarı.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!rank-sıfırla <@Üye></td><td>Seviye ve tecrübe sıfırlama.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!rankmuafkanallar</td><td>Tecrübe vermeyen kanallar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviye-ver <Seviye> <@Üye></td><td>Seviye verme komutu.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!rankmuaf-ekle <#kanal></td><td>Tecrübe vermeyecek kanal ekle.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!rank</td><td><a href=https://marpel.net/tanitim/rank target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviye-ayarla <Seviye> <@Üye></td><td>Seviye değiştirme komutu.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviye-roller</td><td><a href=https://marpel.net/tanitim/rank target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!rank-ayar <sayı></td><td><a href=https://marpel.net/tanitim/rank target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviyeatla-mesaj <metin></td><td>Seviye atlama mesajını belirler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/rank.png"></a> m!seviye-al <Seviye> <@Üye></td><td>Seviye alma komutu.</td>
			</table>

          </div>
      
		</center>
   
          </div>  
                      <center>
                
                    <h1 class="brand">
					
			<a href="https://marpel.net/komutlar/moderasyon.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/moderasyon.png" title="Moderasyon komutlarını görmek için tıkla." width="128" height="128"></a>

            <a href="https://marpel.net/komutlar/extra.php"> <img class="ozellik_btn_i" src="https://marpel.net/resimler/extra.png" title="Extra komutlarını görmek için tıkla." width="128" height="128"></a>
                        
            <a href="https://marpel.net/komutlar/eglence.php"><img class="ozellik_btn_i"src="https://marpel.net/resimler/eglence.png" title="Eğlence komutlarını görmek için tıkla." width="128" height="128"></a>
                              </h1>
                     <br>
<style>

@media (max-width: 1170px) {
    .bg-image {
        width: 70vw;
    }

    .nav-items {
        display: none;
    }

    .nav-wrapper {
        grid-template-columns: 0.7fr 2.5fr;
    }

    .nav-buttons {
        display: grid;
        justify-content: right;
    }

    .nav-footer-holder {
        display: block;
        height: 60px;
        background: #222;
    }

    .nav-footer {
        display: block;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #222;

        box-shadow: 0 -1px 7px 1px black;

        animation: softpop 0.5s;

        z-index: 1000;
    }

    .nav-footer ul {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1fr;
        justify-content: center;
        
        list-style: none;

        text-align: center;
    }

    .nav-footer li {
        margin: 20px;
    }  
    .nav-footer i {
        display: block;
        font-size: 1.2rem;
    }

    .navf-item.active, .navf-item:hover, .navf-item:active {
        color: #ff2f8b;
        text-shadow: 0 0 10px #ff2f8b;
    }

/*
FOOTER START
*/
footer {
    background: #222;
    color: #ddd;
    padding: 15px 60px;
    top: auto;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    justify-content: center;
    align-items: center;
}

footer h3 {
    font-weight: 300;
}

footer img {
    width: 50px;
}

.footer-brand {
    display: grid;
    justify-content: left;
}
.footer-logo {
    display: grid;
    justify-content: center;
}
.footer-by {
    display: grid;
    justify-content: right;
}
.footer-by-col {
    display: grid;
    align-items: center;
    
    grid-template-columns: 1fr 1fr;
    column-gap: 20px;

    text-align: center;
}
/*
FOOTER END
*/

}

              
</style>
 

        <footer class="buFooter">
        <div class="footer-brand">
            <h3>Marpel <i class="fa fa-copyright glow-text" aria-hidden="true"></i> 2020</h3>
        </div>
        <div class="footer-logo">
            <img src="https://marpel.net/marpel.png" alt="Marpel Logosu">
        </div>
        <div class="footer-by">
            <div class="footer-by-col">
                <h3>Bot<br/><span class="glow-text">Mrtol</span></h3>
                <h3>Webmaster <br/><span class="glow-text">MegaCrafter</span></h3>
            </div>
        </div>
    </footer>

    <div class="nav-footer-holder"></div>
    <div class="nav-footer">
        <ul>
                    <li><a href="/" class="navf-item active">Ana Sayfa</a></li>
                    <li><a href="/tanitimlar"
                         class="navf-item">Tanıtımlar</a></li>
                    <li><a href="/komutlar.php" class="navf-item">Komutlar</a></li>
                <li><a href="/embed" class="navf-item">Embed Oluşturucu</a></li>
                </ul>
    </div>
    <script>function jqueryLoaded(){$(".nav>li").click(function(){$(".active").toggleClass("active"),$(this).toggleClass("active")});}</script>
	<script defer async src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" onload="jqueryLoaded"></script> 
  </body>
</html>
