
<!DOCTYPE html>
<html lang="en">
<head>


       <link rel="stylesheet" href="/css/style.css"/>
    <link rel="stylesheet" href="/css/komutlar.css"/>
  
	<link rel="shortcut icon" href="/resimler/marpel.png" type="image/x-icon" >

  		<link rel="shortcut icon" href="https://marpel.net/resimler/marpel.png" type="image/x-icon" >

		
      <meta charset="UTF-8">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.1.7/css/fork-awesome.min.css" integrity="sha256-gsmEoJAws/Kd3CjuOQzLie5Q3yshhvmo7YNtBG7aaEY=" crossorigin="anonymous">

	<link rel="shortcut icon" href="https://marpel.net/resimler/marpel.png" type="image/x-icon" >

		

     <title>Marpel Bot | Moderasyon Komutları</title>
  </head>

<body>

    <img class="bg-image" src="https://marpel.net/marpel.png" aria-hidden="true" />


    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.1.7/css/fork-awesome.min.css" integrity="sha256-gsmEoJAws/Kd3CjuOQzLie5Q3yshhvmo7YNtBG7aaEY=" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css"/>
	

</head> 
<nav>
        <div class="nav-wrapper">
            <ul>
                <li><a href="/"><img src="https://marpel.net/marpel.png" alt="Marpel Logosu"></a></li>
            </ul>
            <div class="nav-items">
                <ul>
                    <li><a href="/" class="nav-item">Ana Sayfa</a></li>
                    <li><a href="/tanitimlar"
                         class="nav-item navv">Tanıtımlar</a></li>
                    <li><a href="/komutlar.php" class="nav-item navvv">Komutlar</a></li>
                  <li><a href="/embed"class="nav-item navvvv">Embed Oluşturucu</a></li>
                </ul>
            </div>
            <div class="nav-buttons">
              <ul>
                    <li><a href="https://discord.gg/t8dvKdr" target="_blank" 
                         class="btn white-hollow-btn">Destek Sunucusu</a></li>
                    <li><a href="https://discord.com/oauth2/authorize?client_id=490039330388180992&permissions=8&scope=bot" target="_blank" rel="noopener" class="btn primary-btn"><i class="fa fa-discord" aria-hidden="true"></i> Davet Et</a></li>
                                  <li><a href="https://discord.com/oauth2/authorize?client_id=490039330388180992&permissions=8&scope=bot" target="_blank" rel="noopener" class="nav-item"><i class="fal fa-sign-in fa-3x"></i></a></li>
                
              </ul>
            </div>
        </div>
    </nav>	

            <div class="section-wrapper">
        <center>
                <div class="overview-card">
                    <h1 class="brand">
            <a href="https://marpel.net/komutlar/extra.php"> <img class="ozellik_btn_i" src="https://marpel.net/resimler/extra.png" title="Extra komutlarını görmek için tıkla." width="128" height="128"></a>
            
            <a href="https://marpel.net/komutlar/rank.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/rank.png" title="Rank komutlarını görmek için tıkla." width="128" height="128"></a>
            
            <a href="https://marpel.net/komutlar/eglence.php"><img class="ozellik_btn_i"src="https://marpel.net/resimler/eglence.png" title="Eğlence komutlarını görmek için tıkla." width="128" height="128"></a>
                              </h1>
                      </div>
        
		<script src="https://marpel.net/util/komutlar.js"></script>
		<script src="https://marpel.net/util/komutlar.js"></script>
      <script>
        function update() {
          myFunction();
          var rows = document.getElementById("myTable").rows;
          var count = -1;
          for (let i = 0;i<rows.length;i++) {
            if (rows[i].style[0]!="display") count++;
          }
          document.getElementById("cmdcount").innerHTML = `Komut [${count}]`;
        }  
      </script>
<center>
  <br />
			<input type="text" style="color:#fff" id="myInput" onkeyup="update()" placeholder="Komut Ara..." title="Aramak istediğiniz kelimeyi girin!">
			<br>
			<br>
      <div>
      <br>
			<table id="myTable">
				<tr class="header">
        
          <th style="width:auto%;" id="cmdcount"> <font color:"white">Komut [65</font>]</th>
					<th style="width:auto%;">Açıklama</th>
        
       		<tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!destek <#Kanal></td><td>Destek kanalını ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!ceza-kaldır <@Üye></td><td>Girilen üyenin cezasını kaldırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-komut-çıkar <komut></td><td>Komut yasağını kaldırır</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!galeri <#Kanal></td><td>Galeri kanalını ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!prefix <Prefix></td><td>Marpelin komut prefixini özelleştirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yavaşmod <sayı> <#kanal></td><td>Kanalın yavaş modunu ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!özelkomut-çıkar <Komut></td><td>ÖzelKomut Sistemi</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!sunucuikon <link></td><td>Sunucu ikonunu değiştirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!linkmuaf-çıkar <#Kanal></td><td>Kanalın reklam muafını kaldırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!ban <@Üye> <Sebep> <Süre></td><td>Girilen üyeyi yasaklar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talep-log <#Kanal></td><td>Talep log kanalı ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!davetrol-ekle <Sayı> <@Rol></td><td><a href=https://marpel.net/tanitim/davet target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talepleri-kapat</td><td>Sunucudaki destek taleplerini kapatır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!davetrol-çıkar <Sayı> <@Rol></td><td><a href=https://marpel.net/tanitim/davet target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!emoji-indir</td><td>Sunucudaki tüm emojileri indirip size gönderir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!öneri <#Kanal></td><td>Öneri kanalını ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!banaffı</td><td>Yasaklı üye listesini temizler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!isim-düzelt</td><td>Uygunsuz üye isimlerini değiştirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-kanal-ekle <#Kanal></td><td>Botu kanalda devre dışı bırakır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!hedef-belirle <sayı></td><td>Sunucu için üye sayısı hedefi belirler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!giriş-ayar <sayı></td><td>Giriş fotoğrafını ve renkleri düzenleme.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!kullanıcıadlarınısıfırla</td><td>Üyelerin kullanıcı adlarını sıfırlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!herkestenrolal <@Rol></td><td>Tüm üyelerden rol alır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!görevli-ekle <kullanıcı></td><td>Görevli ekler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!mute <@Üye> <Sebep> <Süre></td><td>Girilen üyeyi susturur.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!emoji-ekle <isim> <url></td><td>Sunucuya emoji ekler</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!isim-düzeltme <metin></td><td>Uygunsuz isimli üyelere verilecek ad.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-kelimeleri-sıfırla</td><td>Yasaklı kelimeleri sıfırlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talep-özel-log</td><td>Logları özel mesaj olarak gönderir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!uyarıekle <@üye> <sebep></td><td>İstenen üyeyi uyarır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!çıkış-ayar <sayı></td><td>Çıkış fotoğrafını ve renkleri düzenleme.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!görevli-çıkar <kullanıcı></td><td>Görevli çıkarır</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!özelkomut-ekle <Komut></td><td>ÖzelKomut Sistemi</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!emoji-sil <isim></td><td>İsmi girilen emojiyi sunucudan siler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!tepkirol-çıkar <mesajid> <emoji></td><td><a href=https://marpel.net/tanitim/tepkirol target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!rol-al <@Üye> <@Rol></td><td>İstenen üyenin rolünü alır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talep-yetkili-ekle <@Rol></td><td>Talep yetkili rolü ekle.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!tepki-destek <mesajid> <emoji></td><td>Tepkiye basınca destek talebi açar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!log</td><td>Loglar Sistemi</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!ban-kaldır <Üye ID></td><td>İdsi girilen üyenin yasağını kaldırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!tepkirol-ekle <mesajid> <emoji> <@rol></td><td><a href=https://marpel.net/tanitim/tepkirol target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!tepkirol-sınır <mesajid></td><td><a href=https://marpel.net/tanitim/tepkirol target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!oto-rol <@Rol></td><td>Yeni üyelere verilecek rol.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-komut-ekle <Komut></td><td>İstenen komutu yasaklar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-kelime-ekle</td><td>Belirli kelimeyi yasaklar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!isim-değiştir <@Üye> <İsim></td><td>Girilen üyenin ismini değiştirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!herkeserolver <@Rol></td><td>Tüm üyelere belirlenen rolü verir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!davet-sıfırla <@Üye></td><td>Davetleri sıfırlama.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!rol-ver <@Üye> <@Rol></td><td>İstenen üyeye rol verir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!mesajlarısil <sayı></td><td>İstenen miktarda mesaj sildirir.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!ceza-rol <@Rol></td><td>Sustur komutunun vereceği rolü ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!kanallarısil <#kanallar></td><td>Etiketlenen kanalları siler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!emoji-yükle</td><td>Rardaki fotoğrafları emoji olarak ekler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!link-engel</td><td>Sunucuda link atılmasını engeller.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talep-süre <Süre></td><td>Taleplerin kapanma süresini ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-kanal-çıkar <#Kanal></td><td>Kanal yasağını kaldırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!çekiliş <Ödül> <Süre></td><td><a href=https://marpel.net/tanitim/cekilis target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!yasaklı-kelime-çıkar</td><td>Yasaklı kelimeyi kaldırır.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!davetlog <#Kanal></td><td><a href=https://marpel.net/tanitim/davet target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talep-yetkili-çıkar <@Rol></td><td>Talep yetkili rolü çıkar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!talep-yetkili-bilgi</td><td>Açılan talepte yetkilileri listeler.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!istatistik-kur <isim> <değişken(ler)></td><td><a href=https://marpel.net/tanitim/istatistik target=_blank>[Bilgi için tıkla] </td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!caps-lock <yüzde></td><td>Aşırı capslock kullanımını engeller.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!reklam-ikon <link></td><td>Reklam uyarı fotoğrafını ayarlar.</td><tr><td><img width="16" height="16" style="position:relative; top:1px;" src="https://marpel.net/resimler/moderasyon.png"></a> m!linkmuaf-ekle <#Kanal></td><td>Belirli kanalda reklama izin verir.</td>
			</table>

          </div>
      
		</center>
   
          </div>  
                      <center>
                
                    <h1 class="brand">
					
            <a href="https://marpel.net/komutlar/extra.php"> <img class="ozellik_btn_i" src="https://marpel.net/resimler/extra.png" title="Extra komutlarını görmek için tıkla." width="128" height="128"></a>
            
            <a href="https://marpel.net/komutlar/rank.php"><img class="ozellik_btn_i" src="https://marpel.net/resimler/rank.png" title="Rank komutlarını görmek için tıkla." width="128" height="128"></a>
            
            <a href="https://marpel.net/komutlar/eglence.php"><img class="ozellik_btn_i"src="https://marpel.net/resimler/eglence.png" title="Eğlence komutlarını görmek için tıkla." width="128" height="128"></a>
                              </h1>
                     <br>
<style>

@media (max-width: 1170px) {
    .bg-image {
        width: 70vw;
    }

    .nav-items {
        display: none;
    }

    .nav-wrapper {
        grid-template-columns: 0.7fr 2.5fr;
    }

    .nav-buttons {
        display: grid;
        justify-content: right;
    }

    .nav-footer-holder {
        display: block;
        height: 60px;
        background: #222;
    }

    .nav-footer {
        display: block;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #222;

        box-shadow: 0 -1px 7px 1px black;

        animation: softpop 0.5s;

        z-index: 1000;
    }

    .nav-footer ul {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1fr;
        justify-content: center;
        
        list-style: none;

        text-align: center;
    }

    .nav-footer li {
        margin: 20px;
    }  
    .nav-footer i {
        display: block;
        font-size: 1.2rem;
    }

    .navf-item.active, .navf-item:hover, .navf-item:active {
        color: #ff2f8b;
        text-shadow: 0 0 10px #ff2f8b;
    }

/*
FOOTER START
*/
footer {
    background: #222;
    color: #ddd;
    padding: 15px 60px;
    top: auto;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    justify-content: center;
    align-items: center;
}

footer h3 {
    font-weight: 300;
}

footer img {
    width: 50px;
}

.footer-brand {
    display: grid;
    justify-content: left;
}
.footer-logo {
    display: grid;
    justify-content: center;
}
.footer-by {
    display: grid;
    justify-content: right;
}
.footer-by-col {
    display: grid;
    align-items: center;
    
    grid-template-columns: 1fr 1fr;
    column-gap: 20px;

    text-align: center;
}
/*
FOOTER END
*/

}

              
</style>
 

        <footer class="buFooter">
        <div class="footer-brand">
            <h3>Marpel <i class="fa fa-copyright glow-text" aria-hidden="true"></i> 2020</h3>
        </div>
        <div class="footer-logo">
            <img src="https://marpel.net/marpel.png" alt="Marpel Logosu">
        </div>
        <div class="footer-by">
            <div class="footer-by-col">
                <h3>Bot<br/><span class="glow-text">Mrtol</span></h3>
                <h3>Webmaster <br/><span class="glow-text">MegaCrafter</span></h3>
            </div>
        </div>
    </footer>

    <div class="nav-footer-holder"></div>
    <div class="nav-footer">
        <ul>
                    <li><a href="/" class="navf-item active">Ana Sayfa</a></li>
                    <li><a href="/tanitimlar"
                         class="navf-item">Tanıtımlar</a></li>
                    <li><a href="/komutlar.php" class="navf-item">Komutlar</a></li>
                <li><a href="/embed" class="navf-item">Embed Oluşturucu</a></li>
                </ul>
    </div>
    <script>function jqueryLoaded(){$(".nav>li").click(function(){$(".active").toggleClass("active"),$(this).toggleClass("active")});}</script>
	<script defer async src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" onload="jqueryLoaded"></script> 
  </body>
</html>
